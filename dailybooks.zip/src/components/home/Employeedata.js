const EmployeeList=[
    {
        id:1,
        Invoice:'g0001',
        Date:'20/12/2023',
        Company:'TCS',
        Email:'tcs@gmail.com',
        Customer:'yes',
        Status:'Available'
    },
    {
        id:2,
        Invoice:'F0001',
        Date:'20/12/2023',
        Company:'google',
        Email:'google@gmail.com',
        Customer:'yes',
        Status:'Available'
    },
    {
        id:3,
        Invoice:'E0001',
        Date:'20/12/2023',
        Company:'Wibro',
        Email:'wibro@gmail.com',
        Customer:'yes',
        Status:'Available'
    },


]

export default EmployeeList;